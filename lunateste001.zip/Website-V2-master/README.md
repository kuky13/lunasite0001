# Website
This is the official Website for Disconnect Bot. This project hasn't been worked on for around about 2 months. I am releasing the source code for Disconnect for anyone to go and view and see. There may be the occasional error but I am no longer working on this project.

Thank you.
